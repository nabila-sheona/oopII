﻿using lab5_210042111_lsp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_210042111_lsp
{
    public class getaccount
    {
      
        
    }
}
