﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_B_alter
{
    public class Movie
    {
  
        public string title { get; set; }
        public genre genre { get; set; }

        public DateTime release { get; set; }

        public int duration { get; set; }

        public Movie(string title, genre genre, DateTime release, int duration)
        {

            this.title = title;
            this.genre = genre;
            this.release = release;
            this.duration = duration;

         
          
        }





    }
}
